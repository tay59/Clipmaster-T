
import React, { useState } from 'react';

export default function Editor() {
  const [video, setVideo] = useState(null);
  const [effects, setEffects] = useState('Auto');

  return (
    <div className="space-y-4">
      <input
        type="file"
        accept="video/*"
        onChange={(e) => setVideo(e.target.files[0])}
        className="bg-gray-800 p-2 rounded"
      />
      <select
        value={effects}
        onChange={(e) => setEffects(e.target.value)}
        className="bg-gray-800 p-2 rounded"
      >
        <option>Auto</option>
        <option>Flash</option>
        <option>Lyrics Sync</option>
        <option>Slow-Mo</option>
        <option>Speed-Ramp</option>
      </select>
      <button className="bg-green-600 px-4 py-2 rounded hover:bg-green-500">
        ✂️ Générer le clip IA
      </button>
      {video && <p className="text-sm">Fichier sélectionné : {video.name}</p>}
    </div>
  );
}
