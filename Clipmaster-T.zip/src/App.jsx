
import React from 'react';
import Editor from './components/Editor';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white p-4">
      <h1 className="text-4xl font-bold mb-6">🎬 Clipmaster T</h1>
      <Editor />
    </div>
  );
}
